const allowedOrigins = [
    'http://localhost:5173',
    'http://localhost:4200'

];

module.exports = allowedOrigins;